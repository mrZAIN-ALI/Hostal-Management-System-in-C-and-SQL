﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hostal_Management_System
{
    public partial class UpdateDeleteStudent : Form
    {
        Function fn = new Function();
        string query;
        public UpdateDeleteStudent()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UpdateDeleteStudent_Load(object sender, EventArgs e)
        {
            this.Location = new Point(350, 150);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clearAll();
        }
        private void clearAll()
        {
            txtregNo.Clear();
            txtName.Clear();
            txtFather.Clear();
            txtMother.Clear();
            txtEmail.Clear();
            txtPermanent.Clear();
            txtCollege.Clear();
            txtIdProof.Clear();
            txtRoomNo.Clear();
            ComboBoxLiving.SelectedIndex = -1;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            query = "select * from newStudent where regNo = '" + txtregNo.Text + "'";
            DataSet ds = fn.getData(query);

            if(ds.Tables[0].Rows.Count != 0)
            {
                txtName.Text= ds.Tables[0].Rows[0][1].ToString();
                txtFather.Text= ds.Tables[0].Rows[0][2].ToString();
                txtMother.Text= ds.Tables[0].Rows[0][3].ToString();
                txtEmail.Text=ds.Tables[0].Rows[0][4].ToString();
                txtPermanent.Text = ds.Tables[0].Rows[0][5].ToString();
                txtCollege.Text = ds.Tables[0].Rows[0][6].ToString();
                txtIdProof.Text = ds.Tables[0].Rows[0][7].ToString();
                txtRoomNo.Text = ds.Tables[0].Rows[0][8].ToString();
                ComboBoxLiving.Text = ds.Tables[0].Rows[0][9].ToString();
            }
            else
            {
                clearAll();
                MessageBox.Show("No Record Found For this Reg No","Information",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            String regNo = txtregNo.Text;
            String name =txtName.Text;
            String fname =txtFather.Text;
            String mname = txtMother.Text;
            String email = txtEmail.Text;
            String paddress = txtPermanent.Text;
            String college = txtCollege.Text;
            String idProof = txtIdProof.Text;
            Int64 roomNo = Int64 .Parse(txtRoomNo.Text);
            String livingStatus = ComboBoxLiving.Text;

            query = "update newstudent set name ='" + name + "',fname='" + fname + "',mname='" + mname + "',email='" + email + "',paddress='" + paddress + "',college='" + college + "',idproof='" + idProof + "',roomNo=" + roomNo + ",living='" + livingStatus + "' where regNo ='" + regNo + "' update rooms set Booked ='"+livingStatus+"' where roomNo="+roomNo+" ";
            fn.setData(query, "Data Updation Successful");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Are You Sure? ","Confirmation",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)==DialogResult.Yes)
            {
                query = "delete from newStudent where regNo ='" + txtregNo.Text + "'";
                fn.setData(query, "Student Record Deleted");
                clearAll();
            }
            
            
        }
    }
}
