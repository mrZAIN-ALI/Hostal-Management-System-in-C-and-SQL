﻿using System;
using System.Windows.Forms;

namespace Hostal_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void signInButton_Click(object sender, EventArgs e)
        {
            if (txtUsername.Text == "zain ali" && txtPassword.Text == "pass")
            {
                dashBoard dashBoard = new dashBoard();
                this.Hide();
                dashBoard.Show();
            }
            else if (txtUsername.Text == "umar" && txtPassword.Text == "pass")
            {
                dashBoard dashBoard = new dashBoard();
                this.Hide();
                dashBoard.Show();
            }
            else if (txtUsername.Text == "haseeb" && txtPassword.Text == "pass")
            {
                dashBoard dashBoard = new dashBoard();
                this.Hide();
                dashBoard.Show();
            }
            else
            {
                txtPassword.Clear();
            }
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
