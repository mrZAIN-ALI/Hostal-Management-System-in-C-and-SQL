﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hostal_Management_System
{
    public partial class EmployeePayment : Form
    {
        Function fn = new Function();
        string query;

        public EmployeePayment()
        {
            InitializeComponent();
        }

        private void EmployeePayment_Load(object sender, EventArgs e)
        {
            this.Location = new Point(350, 170);

        }

        private void monthDateTime_ValueChanged(object sender, EventArgs e)
        {
            monthDateTime.Format = DateTimePickerFormat.Custom;
            monthDateTime.CustomFormat = "MMMM YYYY";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if(txtempId.Text!="")
            {
                query = "select ename,eemail,edesignation from newEmployee where eid='" + txtempId.Text + "'";
                DataSet ds = fn.getData(query);
                if(ds.Tables[0].Rows.Count!=0)
                {
                    txtName.Text = ds.Tables[0].Rows[0][0].ToString();
                    txtEmailId.Text=ds.Tables[0].Rows[0][1].ToString();
                    txtDesignation.Text=ds.Tables[0].Rows[0][2].ToString();
                    setDataGrid(txtempId.Text);
                }
                else
                {
                    MessageBox.Show("No Record Exit", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Enter Required Field", "Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        public void setDataGrid(string empId)
        {
            query = "select * from employeeSalary where empId = '" + empId + "'";
            DataSet ds = fn.getData(query);
            guna2DataGridView1.DataSource = ds.Tables[0];
        }

        private void btnPaySalary_Click(object sender, EventArgs e)
        {
            if(txtempId.Text!="" && txtPaymentAmount.Text!="")
            {
                query = "select * from employeeSalary where empId = '" + txtempId.Text+ "' and fmonth ='"+monthDateTime.Text+"'";
                DataSet ds = fn.getData(query);

                if(ds.Tables[0].Rows.Count==0)
                {
                    string empId = txtempId.Text;
                    string month = monthDateTime.Text;
                    Int64 amount = Int64.Parse(txtPaymentAmount.Text);

                    query = "insert into employeeSalary values('" + empId + "','" + month + "'," + amount + ")";
                    fn.setData(query, "Salary for " + monthDateTime.Text + " Paid");
                    setDataGrid(empId);
                }
                else
                {
                    MessageBox.Show("Payment of"+monthDateTime.Text+" Done.","Information",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clearAll();
        }
        public void clearAll()
        {
            txtempId.Clear();
            txtName.Clear();
            txtDesignation.Clear();
            txtEmailId.Clear();
            txtPaymentAmount.Clear();
            guna2DataGridView1.DataSource = 0;
            monthDateTime.ResetText();
        }
    }
}
