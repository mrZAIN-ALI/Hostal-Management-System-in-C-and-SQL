﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hostal_Management_System
{
    public partial class Newstudent : Form
    {
        Function fn = new Function();
        String query;
        public Newstudent()
        {
            InitializeComponent();
        }

        private void guna2HtmlLabel2_Click(object sender, EventArgs e)
        {

        }

        private void guna2HtmlLabel9_Click(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Newstudent_Load(object sender, EventArgs e)
        {
            this.Location = new Point(350, 170);
            query = "Select roomNo from rooms where roomStatus = 'Yes' and Booked='No'";
            DataSet ds = fn.getData(query);

            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                Int64 room = Int64.Parse(ds.Tables[0].Rows[i][0].ToString());
                comboRoomNo.Items.Add(room);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clearAll();
        }

        public void clearAll()
        {
            txtregNo.Clear();
            txtName.Clear();
            txtFather.Clear();
            txtMother.Clear();
            txtEmail.Clear();
            txtCollege.Clear();
            txtIdProof.Clear();
            txtPermanent.Clear();
            comboRoomNo.SelectedIndex = -1;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtregNo.Text != "" && txtName.Text != "" && txtFather.Text != "" && txtMother.Text != "" && txtEmail.Text != "" && txtPermanent.Text != "" && txtCollege.Text != "" && txtIdProof.Text != "" && comboRoomNo.SelectedIndex != -1)
            {
                string regNo = txtregNo.Text;
                string name = txtName.Text;
                string fname = txtFather.Text;
                string mname = txtMother.Text;
                string email = txtEmail.Text;
                string paddress = txtPermanent.Text;
                string college = txtCollege.Text;
                string idproof = txtIdProof.Text;
                Int64 roomNo = Int64.Parse(comboRoomNo.Text);

                query = "insert into newStudent (regNo,name,fname,mname,email,paddress,college,idproof,roomNo) values('" + regNo + "', '" + name + "','" + fname + "','" + mname + "','" + email + "','" + paddress + "','" + college + "','" + idproof + "'," + roomNo + ") update rooms set booked = 'Yes' where roomNo =" + roomNo + "";
                fn.setData(query, "Student Registrartion Successfull. ");
                clearAll();
            }
            else
            {
                MessageBox.Show("Fill All Required Details.", "Information!! ", MessageBoxButtons.OK, MessageBoxIcon.Warning); 
            }
        }
    }
}
