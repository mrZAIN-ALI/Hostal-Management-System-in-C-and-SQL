﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hostal_Management_System
{
    

    public partial class StudentFees : Form
    {

        Function fn = new Function();
        string query;
        public StudentFees()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void StudentFees_Load(object sender, EventArgs e)
        {
            this.Location = new Point(350, 170);
            dateTimePicker.Format=DateTimePickerFormat.Custom;
            dateTimePicker.CustomFormat = "MMMM YYYY";
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if(txtregNo.Text != "")
            {
                query = "select name, email,roomNo from newStudent where regNo='" + txtregNo.Text + "'";
                DataSet ds = fn.getData(query);

                if(ds.Tables[0].Rows.Count != 0)
                {
                    txtName.Text = ds.Tables[0].Rows[0][0].ToString();
                    txtEmailId.Text = ds.Tables[0].Rows[0][1].ToString();
                    txtRoomNo.Text=ds.Tables[0].Rows[0][2].ToString();
                    setDatGrid(txtregNo.Text);

                }
                else
                {
                    MessageBox.Show("No Record Exist", "Information", MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
            }
        }
        public void setDatGrid(string regNo)
        {
            query = "select * from fees where regNo = '" + regNo + "'";
            DataSet ds = fn.getData(query);
            guna2DataGridView1.DataSource = ds.Tables[0];
        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            if(txtregNo.Text != "" && txtAmount.Text!= "")
            {
                query = "select * from fees where regNo = '" + txtregNo.Text + "' and fmonth ='"+dateTimePicker.Text+"'";
                DataSet ds = fn.getData(query);
                if (ds.Tables[0].Rows.Count == 0)
                {
                    string regNo = txtregNo.Text;
                    string month = dateTimePicker.Text;
                    Int64 amount = Int64.Parse(txtAmount.Text);
                    query = "insert into fees values('" + regNo + "','" + month + "'," + amount + ")";
                    fn.setData(query, "Fees Paid");
                    clearAll();
                }
                else
                {
                    MessageBox.Show("No dues of " + dateTimePicker.Text + " Left","Information",MessageBoxButtons.OK,MessageBoxIcon.Information);
                }
            }

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clearAll();
        }
        public void clearAll()
        {
            txtregNo.Clear();
            txtName.Clear();
            txtAmount.Clear();
            txtRoomNo.Clear();
            txtEmailId.Clear();
            guna2DataGridView1.DataSource = 0;

        }
    }
}
