﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hostal_Management_System
{
    public partial class NewEmployee : Form
    {
        Function fn = new Function();
        string query;

        public NewEmployee()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void NewEmployee_Load(object sender, EventArgs e)
        {
            this.Location = new Point(350, 170);

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(txteId.Text!="" && txtName.Text!="" && txtFather.Text != "" && txtMother.Text != "" && txtEmailId.Text != "" && txtPermanent.Text != "" && txtUniqueId.Text != "" && txtDesignation.SelectedIndex!=-1)
            {
                string eId = txteId.Text;
                string name = txtName.Text;
                string fname = txtFather.Text;
                string mname = txtMother.Text;
                string email = txtEmailId.Text;
                string address = txtPermanent.Text;
                string id = txtUniqueId.Text;
                string designation = txtDesignation.Text;
                query = "insert into newEmployee(eId,ename,efname,emname,eemail,epaddress,eidproof,edesignation) values('" + eId + "','" + name + "','" + fname + "','" + mname + "','" + email + "','" + address + "','" + id + "','" + designation + "')";
                fn.setData(query, "Employee Registration Successful.");
                clearAll();
            }
            else
            {
                MessageBox.Show("Fill All Required Fields", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clearAll();
        }
        private void clearAll()
        {
            txteId.Clear();
            txtName.Clear();
            txtFather.Clear();
            txtMother.Clear();
            txtEmailId.Clear();
            txtPermanent.Clear();
            txtUniqueId.Clear();
            txtDesignation.SelectedIndex = -1;
        }
    }
}
