﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hostal_Management_System
{
    class Function
    {
        protected SqlConnection getConnection()
        {
            SqlConnection conection = new SqlConnection();
            conection.ConnectionString = "data source =DESKTOP-JMOA4Q2\\SQLEXPRESS01; database=hostel ; integrated security=True";
            return conection;
        }

        public DataSet getData(String query)
        {
            SqlConnection conection = getConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conection;
            cmd.CommandText = query;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }

        public void setData(String query, String msg)
        {
            SqlConnection con = getConnection();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            con.Open();
            cmd.CommandText = query;
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show(msg, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
