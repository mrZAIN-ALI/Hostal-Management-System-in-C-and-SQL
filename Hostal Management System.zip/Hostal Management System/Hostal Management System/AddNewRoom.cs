﻿using Hostal_Management_System.ServiceReference1;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hostal_Management_System
{
    public partial class AddNewRoom : Form
    {

        Function fn = new Function();
        String query;
        public AddNewRoom()
        {
            InitializeComponent();
        }
        ServiceReference1.Service1Client client = new ServiceReference1.Service1Client();
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AddNewRoom_Load(object sender, EventArgs e)
        {
            this.Location = new Point(350, 170);
            labelRoom.Visible = false;
            labelRoomExit.Visible = false;

            query = "select * from rooms";
            DataSet ds = fn.getData(query);

            DataGridView1.DataSource= ds.Tables[0];
        }

        private void btnAddRoom_Click(object sender, EventArgs e)
        {
            query = "select * from rooms where roomNo=" + txtRoomNo1.Text + "";
            DataSet ds = fn.getData(query);
            if (ds.Tables[0].Rows.Count == 0)
            {
                String status;
                if (CheckBox1.Checked)
                {
                    status = "Yes";
                }
                else
                {
                    status = "No";
                }
                labelRoomExit.Visible = false;

                query = "insert into rooms (roomNo, roomStatus) values(" + txtRoomNo1.Text + ", '" + status + "') ";
                fn.setData(query, "Room Added ");

                AddNewRoom_Load(this, null);
            }
            else
            {
                labelRoomExit.Text = "Room All Ready Exist.";
                labelRoomExit.Visible = true;
            }

            ////test code
            //query = "select * from rooms where roomNo=" + txtRoomNo1.Text + "";
            //DataSet ds = fn.getData(query);
            //if (ds.Tables[0].Rows.Count == 0)
            //{
            //    String status;
            //    if (CheckBox1.Checked)
            //    {
            //        status = "Yes";
            //    }
            //    else
            //    {
            //        status = "No";
            //    }
            //    labelRoomExit.Visible = false;

            //    //query = "insert into rooms (roomNo, roomStatus) values(" + txtRoomNo1.Text + ", '" + status + "') ";
            //    InsertRoom room= new InsertRoom();
            //    room.RoomNo = Convert.ToInt32(txtRoomNo1.Text);
            //    room.RoomStatus= status;

            //    client.insertRoom(room);
            //    //fn.setData(query, "Room Added ");

            //    AddNewRoom_Load(this, null);
            //}
            //else
            //{
            //    labelRoomExit.Text = "Room All Ready Exist.";
            //    labelRoomExit.Visible = true;
            //}

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            query = "select * from rooms where roomNo=" + txtRoomNo2.Text + "";
            DataSet ds = fn.getData(query);
            if (ds.Tables[0].Rows.Count == 0)
            {
                labelRoom.Text = "No Room Exist.";
                labelRoom.Visible = true;
                CheckBox2.Checked = false;
            }
            else
            {
                labelRoom.Text = "Room Found.";
                labelRoom.Visible = true;


                if (ds.Tables[0].Rows[0][1].ToString() == "Yes")
                {
                    CheckBox2.Checked = true;
                }
                else
                {
                    CheckBox2.Checked = false;

                }
            }
        }

        private void bntUpdate_Click(object sender, EventArgs e)
        {
            String status;
            if (CheckBox2.Checked)
            {
                status = "Yes";
            }
            else
            {
                status = "No";
            }
            query = "update rooms set roomStatus='" + status + "' where roomNo = "+txtRoomNo2.Text+"";
            fn.setData(query, "Details Updated.");
            AddNewRoom_Load(this, null);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (labelRoom.Text == "Room Found.")
            {
                query = "delete from rooms where roomNo=" + txtRoomNo2.Text + "";
                fn.setData(query, "Room Details Deleated.");
                AddNewRoom_Load(this, null);
            }
            else
            {
                MessageBox.Show("Trying to delete which doesn't Exist.", "Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void CheckBox2_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
