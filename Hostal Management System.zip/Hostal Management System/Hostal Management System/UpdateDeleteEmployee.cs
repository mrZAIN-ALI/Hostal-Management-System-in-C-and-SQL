﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Xml.Linq;

namespace Hostal_Management_System
{
    public partial class UpdateDeleteEmployee : Form
    {
        Function fn = new Function();
        String query;
        public UpdateDeleteEmployee()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UpdateDeleteEmployee_Load(object sender, EventArgs e)
        {
            this.Location = new Point(350, 170);
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void guna2TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            String eId = txteId.Text;
            String name = txtName.Text;
            String fname = txtFatherName.Text;
            String mname = TxtMotherName.Text;
            String email = txtEmail.Text;
            String Paddress = txtAdress.Text;
            String id = txtUniqueId.Text;
            String designation = txtDesignation.Text;
            String working = txtWorkingAtatus.Text;
            query="update newEmployee set ename='" + name + "',efname='"+fname+"',emname='"+mname+ "',eemail='" +email+"',epaddress='" +Paddress+"',eidproof = '"+id+"',edesignation='"+designation+"',working='"+working+"' where eId = '"+eId+"'";
            fn.setData(query, "Data Updation Success");
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            query = "select * from newEmployee where eId ='" + txteId.Text + "'";
            DataSet ds = fn.getData(query);
            if (ds.Tables[0].Rows.Count != 0)
            {
                txtName.Text = ds.Tables[0].Rows[0][1].ToString();
                txtFatherName.Text = ds.Tables[0].Rows[0][2].ToString();
                TxtMotherName.Text = ds.Tables[0].Rows[0][3].ToString();
                txtEmail.Text = ds.Tables[0].Rows[0][4].ToString();
                txtAdress.Text = ds.Tables[0].Rows[0][5].ToString();
                txtUniqueId.Text = ds.Tables[0].Rows[0][6].ToString();
                txtDesignation.Text = ds.Tables[0].Rows[0][7].ToString();
                txtWorkingAtatus.Text = ds.Tables[0].Rows[0][8].ToString();
            }
            else
            {
                MessageBox.Show("No Record Exist.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                clearAll();
            }
                    }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you Sure?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                query = "delete from newEmployee where eId = '" + txteId.Text + "'";
                fn.setData(query, "Employee Record Deleted. ");
                clearAll();
            }
        }
        
        public void clearAll()
        {
            txtName.Clear();
            txtAdress.Clear();
            txtDesignation.SelectedIndex= -1;
            txtEmail.Clear();
            txtFatherName.Clear();
            txteId.Clear();
            txtUniqueId.Clear();
            txtWorkingAtatus.SelectedIndex= -1;
            TxtMotherName.Clear();

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            clearAll();
        }
    }
}
