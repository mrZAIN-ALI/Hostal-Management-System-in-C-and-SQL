create database hostel

create table rooms (
  roomNo bigint not null primary key,
  roomStatus varchar(250) not null,
  Booked varchar(150) default 'No'
)
select *from rooms
--INSERT INTO rooms (roomNo, roomStatus, Booked)
--VALUES (101, 'Available', 'No'),
--       (102, 'Unavailable', 'Yes'),
--       (103, 'Available', 'No'),
--       (104, 'Under Maintenance', 'No'),
--       (105, 'Available', 'No');
select�*�from�rooms

create table newStudent(
regNo varchar(50) primary key,
name varchar(250) not null,
fname varchar(250) not null,
mname varchar(250) not null,
email varchar(250) not null,
paddress varchar(250) not null,
college varchar(250) not null,
idproof varchar(250) not null,
roomNo bigint not null,
living varchar(250) default 'Yes',
Foreign key (roomNo) references rooms(roomNo)
)
select *from newStudent
create table fees(
regNo varchar(50),
fmonth varchar(60) not null,
amount bigint not null,
Foreign key (regNo) references newStudent(regNo)
)


Select * from fees

create table newEmployee(
eId varchar(50) primary key,
ename varchar(250) not null,
efname varchar(250) not null,
emname varchar(250) not null,
eemail varchar(250) not null,
epaddress varchar(250) not null,
eidproof varchar(250) not null,
edesignation varchar(250) not null,
working varchar(50) default 'Yes')
select * from newEmployee


go

create table employeeSalary(
empId varchar(50),
fmonth varchar(60) not null,
amount bigint not null
Foreign key (empId) references newEmployee(eid)
)

select * from employeeSalary
